/* ------------------------------------------------------------------
   photo.js — analyse d'un repas et scan de code-barres
   Deux frontières réseau, et elles seules :
     lookup(ean)     → Open Food Facts. Réel, sans clé, sans serveur.
     analyze(img)    → modèle multimodal. Exige un proxy : voir
                       ML.AI_ENDPOINT plus bas. Tant qu'il est vide,
                       l'écran fonctionne en démonstration assumée.
------------------------------------------------------------------- */
window.ML = window.ML || {};

/* URL du proxy d'analyse photo. Vide = mode démonstration.
   La clé du modèle vit sur ce proxy, JAMAIS dans ce fichier :
   ce dépôt est public.                                        */
ML.AI_ENDPOINT = '';

ML.photo = (() => {
  let items = [], stream = null, loop = null, shot = null;

  /* ---------------- caméra ---------------- */
  async function startCamera(videoEl){
    stream = await navigator.mediaDevices.getUserMedia({
      video: {facingMode: {ideal: 'environment'}}, audio: false
    });
    videoEl.srcObject = stream;
    await videoEl.play();
  }
  /* Le flux doit être coupé explicitement, sinon la LED de la caméra
     reste allumée après la fermeture du panneau.                  */
  function stopCamera(){
    if (loop){ clearInterval(loop); loop = null; }
    if (stream){ stream.getTracks().forEach(t => t.stop()); stream = null; }
  }

  /* ---------------- code-barres ---------------- */
  const canScan = () => 'BarcodeDetector' in window && navigator.mediaDevices;

  function scan(){
    ML.shell.panel(ML.shell.head('Code-barres') + `<div class="pbody">
      <div class="frame" id="scanFrame">
        <video id="cam" playsinline muted></video>
        <div class="reticle"></div>
      </div>
      <p class="sub" id="scanMsg" style="margin-top:12px">Vise le code-barres du produit.</p>
      <div class="sec">Ou saisis le code à la main</div>
      <div style="display:flex;gap:6px">
        <input class="search" style="margin:0" id="ean" inputmode="numeric"
               placeholder="Ex. 3017620422003">
        <button class="cta" style="width:auto;margin:0;padding:0 20px;font-size:17px"
                onclick="ML.photo.manual()">OK</button>
      </div>
      <p class="note">La caméra ne quitte pas le téléphone : seul le numéro lu part vers
      Open Food Facts. Un produit trouvé rejoint ta base et sera reconnu hors ligne ensuite.</p>
    </div>`);
    if (canScan()) startScan();
    else msg("Ce navigateur ne sait pas lire les codes-barres. Saisis le numéro à la main.");
  }

  const msg = t => { const e = ML.$('scanMsg'); if (e) e.textContent = t; };

  async function startScan(){
    try {
      await startCamera(ML.$('cam'));
    } catch (e) {
      msg("Caméra refusée. Autorise l'accès, ou saisis le numéro à la main.");
      return;
    }
    const detector = new BarcodeDetector({formats:['ean_13','ean_8','upc_a','upc_e']});
    let busy = false;
    loop = setInterval(async () => {
      const v = ML.$('cam');
      if (!v || busy) return;
      busy = true;
      try {
        const found = await detector.detect(v);
        if (found.length){
          stopCamera();
          resolve(found[0].rawValue);
        }
      } catch (e) { /* image non exploitable sur cette frame */ }
      busy = false;
    }, 400);
  }

  function manual(){
    const v = (ML.$('ean').value || '').replace(/\D/g, '');
    if (v.length < 8) return msg('Un code-barres fait au moins 8 chiffres.');
    stopCamera();
    resolve(v);
  }

  async function resolve(ean){
    msg('Recherche du produit…');
    let p;
    try { p = await lookup(ean); }
    catch (e) { return msg("Pas de réseau. Réessaie, ou ajoute le produit à la main."); }
    if (!p) return msg(`Code ${ean} inconnu d'Open Food Facts. Ajoute-le à la main depuis MANGER.`);
    ML.add.detailCustom(p, 'f',
      [[p.portion, '1 portion'], [p.portion * 2, '2 portions'], [100, '100 g'], [p.pack, 'Le paquet']]);
  }

  /* --- FRONTIÈRE RÉSEAU 1 : Open Food Facts ---
     API publique, sans clé, sans quota bloquant. Base contributive :
     tout ce qui en sort est nettoyé et borné avant affichage.     */
  async function lookup(ean){
    const url = 'https://world.openfoodfacts.org/api/v2/product/' + encodeURIComponent(ean)
              + '.json?fields=product_name,product_name_fr,brands,nutriments,serving_quantity,quantity';
    const r = await fetch(url);
    if (!r.ok) throw new Error('réseau');
    const j = await r.json();
    if (!j || j.status !== 1 || !j.product) return null;

    const pr = j.product, nu = pr.nutriments || {};
    /* Certains produits n'ont que l'énergie en kilojoules. */
    const kcal = +nu['energy-kcal_100g'] || (+nu['energy_100g'] ? +nu['energy_100g'] / 4.184 : 0);
    if (!kcal) return null;

    const name = ML.cleanName(pr.product_name_fr || pr.product_name || '') || 'Produit ' + ean;
    const brand = ML.cleanName((pr.brands || '').split(',')[0] || '');
    const portion = Math.round(+pr.serving_quantity) || 30;
    const pack = Math.round(parseFloat(pr.quantity)) || 200;

    return {
      n: brand && !name.toLowerCase().includes(brand.toLowerCase()) ? `${name} (${brand})` : name,
      k: Math.round(kcal),
      p: +nu.proteins_100g || 0, c: +nu.carbohydrates_100g || 0, f: +nu.fat_100g || 0,
      portion: ML.clamp(portion, 5, 300), pack: ML.clamp(pack, 20, 500),
      src: 'Open Food Facts ·'
    };
  }

  /* ---------------- photo du repas ---------------- */
  function open(){
    ML.shell.panel(ML.shell.head('Photo') + ML.shell.budget() + `<div class="pbody">
      <label class="frame" for="shot" id="shotFrame">
        <div><div style="font-size:42px;opacity:.4">○</div>
        <div class="sub" style="margin-top:10px">Prendre une photo de l'assiette</div></div>
      </label>
      <input type="file" id="shot" class="hide" accept="image/*" capture="environment"
             onchange="ML.photo.preview(this)">
      <input class="search" id="hint" style="margin-top:14px"
             placeholder="Précision : « cuit à l'huile, sauce yaourt »">
      <button class="cta" id="go" onclick="ML.photo.run()">Analyser</button>
      ${ML.AI_ENDPOINT ? '' : `<p class="note"><b>Analyse non branchée.</b> Le bouton renvoie
        une estimation de démonstration pour tester l'écran de validation. Pour une vraie
        analyse, renseigne ML.AI_ENDPOINT dans js/screens/photo.js.</p>`}
    </div>`);
  }

  /* Aperçu local, aucun envoi à ce stade. */
  function preview(input){
    const f = input.files && input.files[0];
    if (!f) return;
    shot = f;
    const url = URL.createObjectURL(f);
    ML.$('shotFrame').innerHTML = `<img src="${url}" alt="Repas photographié">`;
  }

  /* --- FRONTIÈRE RÉSEAU 2 : modèle multimodal ---
     Le modèle ne renvoie jamais de calories : il nomme des aliments du
     vocabulaire local et estime des grammages. Le calcul reste ici.  */
  async function analyze(file, hint){
    if (!ML.AI_ENDPOINT){
      await new Promise(r => setTimeout(r, 700));
      const meal = ML.MOCK_MEALS[Math.floor(Math.random() * ML.MOCK_MEALS.length)];
      return meal.map(x => ({n:x.n, g:x.g}));
    }
    const body = new FormData();
    if (file) body.append('image', file);
    body.append('hint', hint || '');
    body.append('vocabulary', JSON.stringify(ML.FOODS.map(x => x.n)));
    const r = await fetch(ML.AI_ENDPOINT, {method:'POST', body});
    if (!r.ok) throw new Error('analyse indisponible');
    const j = await r.json();
    return Array.isArray(j.items) ? j.items : [];
  }

  async function run(){
    const btn = ML.$('go');
    btn.textContent = 'Analyse…';
    let raw;
    try { raw = await analyze(shot, (ML.$('hint') || {}).value || ''); }
    catch (e) { btn.textContent = 'Analyser'; return ML.shell.toast("Analyse indisponible"); }

    /* Un aliment inconnu du catalogue est écarté : le modèle ne peut
       donc introduire ni valeur ni contenu arbitraire.            */
    items = raw.map(x => ({n:ML.cleanName(x.n), g:+x.g || 0, ref:ML.byName(ML.cleanName(x.n))}))
               .filter(x => x.ref && x.g > 0);
    shot = null;

    if (!items.length){ btn.textContent = 'Analyser'; return ML.shell.toast('Aucun aliment reconnu'); }

    ML.shell.panel(ML.shell.head('À valider') + `<div class="pbody">
      <p class="sub" style="line-height:1.55;margin-bottom:4px">
        Corrige les quantités si besoin, le total se recalcule.</p>
      <div id="ests"></div>
      <div class="big2 num" id="tot"></div>
      <div class="sub">estimation, marge d'environ 20 %</div>
      <button class="cta" onclick="ML.photo.save()">Enregistrer le repas</button>
      <button class="cta ghost" onclick="ML.shell.close()">Annuler</button></div>`);
    renderItems();
  }

  function renderItems(){
    ML.$('ests').innerHTML = items.map((x, i) => `<div class="est">
      <span class="nm">${ML.h(x.n)}</span>
      <input type="number" inputmode="numeric" value="${x.g}"
             oninput="ML.photo.setGrams(${i}, +this.value)">
      <span class="sub">g</span>
      <span class="kc num">${ML.fmt(x.g * x.ref.k / 100)}</span>
      <button class="rm" onclick="ML.photo.drop(${i})" aria-label="Retirer">×</button></div>`).join('');
    const t = total();
    /* Fourchette plutôt qu'un chiffre net : une photo ne connaît ni
       l'huile de cuisson ni la densité réelle du plat.           */
    ML.$('tot').textContent = t ? `≈ ${ML.fmt(t * .92)}–${ML.fmt(t * 1.08)} kcal` : '0 kcal';
  }

  const total = () => items.reduce((s, x) => s + x.g * x.ref.k / 100, 0);
  function setGrams(i, g){ items[i].g = g || 0; renderItems(); }
  function drop(i){ items.splice(i, 1); renderItems(); }

  function totalMacros(){
    const t = {p:0, c:0, f:0, a:0};
    items.forEach(x => {
      const m = ML.scale(x.ref, x.g);
      t.p += m.p; t.c += m.c; t.f += m.f; t.a += m.a;
    });
    return t;
  }

  function save(){
    const t = total();
    if (!t) return ML.shell.close();
    ML.add.commit('Repas photographié', t, items.map(x => x.n).join(', '), 'f', totalMacros());
  }

  return {open, preview, run, scan, manual, save, setGrams, drop, stopCamera, analyze, lookup};
})();
